/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Object
 */
package com.amazon.device.ads;

import android.content.Context;
import com.amazon.device.ads.ak;
import com.amazon.device.ads.bl;
import com.amazon.device.ads.cw;

class al {
    private final a a = new a();

    al() {
    }

    public double a(double d2) {
        return this.a.a(d2);
    }

    public double a(int n2, int n3, int n4, int n5) {
        return this.a.a(n2, n3, n4, n5);
    }

    public float a() {
        return this.a.a();
    }

    public int a(int n2) {
        return this.a.a(n2);
    }

    public void a(bl bl2, cw cw2) {
        this.a.a(bl2, cw2);
    }

    public boolean a(Context context) {
        return this.a.a(context);
    }

    public int b(int n2) {
        return this.a.b(n2);
    }

    private static class a {
        private a() {
        }

        double a(double d2) {
            return ak.a(d2);
        }

        double a(int n2, int n3, int n4, int n5) {
            return ak.a(n2, n3, n4, n5);
        }

        float a() {
            return ak.a();
        }

        int a(int n2) {
            return ak.a(n2);
        }

        void a(bl bl2, cw cw2) {
            ak.a(bl2, cw2);
        }

        boolean a(Context context) {
            return ak.a(context);
        }

        int b(int n2) {
            return ak.b(n2);
        }
    }

}

