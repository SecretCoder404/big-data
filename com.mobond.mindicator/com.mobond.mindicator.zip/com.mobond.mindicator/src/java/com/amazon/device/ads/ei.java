/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.System
 */
package com.amazon.device.ads;

class ei {
    ei() {
    }

    public long a() {
        return System.currentTimeMillis();
    }

    public long b() {
        return System.nanoTime();
    }
}

