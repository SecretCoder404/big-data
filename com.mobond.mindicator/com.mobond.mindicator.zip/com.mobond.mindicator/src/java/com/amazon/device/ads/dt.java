/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.amazon.device.ads;

import com.amazon.device.ads.ds;
import com.amazon.device.ads.h;

interface dt {
    public void a(ds var1, h var2);
}

