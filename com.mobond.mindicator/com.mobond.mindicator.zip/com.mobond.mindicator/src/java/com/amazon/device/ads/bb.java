/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.amazon.device.ads;

import com.amazon.device.ads.ab;
import com.amazon.device.ads.ac;
import com.amazon.device.ads.ba;
import com.amazon.device.ads.cp;
import com.amazon.device.ads.h;

public class bb
implements ac {
    @Override
    public ab a(h h2) {
        return new ba(h2, new cp());
    }
}

