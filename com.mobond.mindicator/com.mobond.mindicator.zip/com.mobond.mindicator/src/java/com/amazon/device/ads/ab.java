/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.amazon.device.ads;

import com.amazon.device.ads.cp;
import com.amazon.device.ads.dt;

interface ab {
    public boolean a();

    public cp.a b();

    public String c();

    public String d();

    public dt e();
}

