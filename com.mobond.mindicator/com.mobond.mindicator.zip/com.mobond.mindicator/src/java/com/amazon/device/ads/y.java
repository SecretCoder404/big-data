/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.amazon.device.ads;

import com.amazon.device.ads.z;

public class y {
    private static final String a = "y";
    private static final z b = new z(a);

    private y() {
    }

    static z a() {
        return b;
    }

    public static final void a(String string) {
        b.a(string);
    }
}

