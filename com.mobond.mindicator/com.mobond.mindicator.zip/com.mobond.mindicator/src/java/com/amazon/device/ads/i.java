/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.amazon.device.ads;

import com.amazon.device.ads.m;
import com.amazon.device.ads.n;
import com.amazon.device.ads.x;

interface i {
    public void a();

    public void a(m var1);

    public void a(n var1);

    public void a(x var1);

    public boolean a(boolean var1);

    public void b();

    public int c();

    public void d();
}

