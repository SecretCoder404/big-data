/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.amazon.device.ads;

import com.amazon.device.ads.ab;
import com.amazon.device.ads.ac;
import com.amazon.device.ads.as;
import com.amazon.device.ads.cp;
import com.amazon.device.ads.h;

class at
implements ac {
    at() {
    }

    @Override
    public ab a(h h2) {
        return new as(h2, new cp());
    }
}

