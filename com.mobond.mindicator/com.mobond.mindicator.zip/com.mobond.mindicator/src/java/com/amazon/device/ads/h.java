/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewTreeObserver
 *  android.view.ViewTreeObserver$OnGlobalLayoutListener
 *  com.amazon.device.ads.j
 *  java.lang.Object
 *  java.lang.String
 */
package com.amazon.device.ads;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import com.amazon.device.ads.ag;
import com.amazon.device.ads.dk;
import com.amazon.device.ads.dm;
import com.amazon.device.ads.dp;
import com.amazon.device.ads.dt;
import com.amazon.device.ads.ef;
import com.amazon.device.ads.j;
import com.amazon.device.ads.l;
import com.amazon.device.ads.n;

class h {
    private final j a;

    public h(j j2) {
        this.a = j2;
    }

    public String A() {
        return this.a.am();
    }

    public void a() {
        this.a.B();
    }

    public void a(Activity activity) {
        this.a.a(activity);
    }

    public void a(ViewGroup.LayoutParams layoutParams) {
        this.a.a(layoutParams);
    }

    public void a(ViewGroup viewGroup, ViewGroup.LayoutParams layoutParams, boolean bl2) {
        this.a.a(viewGroup, layoutParams, bl2);
    }

    public void a(ViewTreeObserver.OnGlobalLayoutListener onGlobalLayoutListener) {
        this.a.a(onGlobalLayoutListener);
    }

    public void a(dt dt2) {
        this.a.a(dt2);
    }

    public void a(n n2) {
        this.a.b(n2);
    }

    public void a(Object object, boolean bl2, String string) {
        this.a.a(object, bl2, string);
    }

    public void a(String string) {
        this.a.a(string, false);
    }

    public void a(String string, dm dm2) {
        this.a.a(string, dm2);
    }

    public void a(String string, String string2, boolean bl2, dm dm2) {
        this.a.a(string, string2, bl2, dm2);
    }

    public void a(boolean bl2) {
        this.a(bl2, null);
    }

    public void a(boolean bl2, dp dp2) {
        this.a.a(bl2, dp2);
    }

    public void b(ViewTreeObserver.OnGlobalLayoutListener onGlobalLayoutListener) {
        this.a.b(onGlobalLayoutListener);
    }

    public void b(String string) {
        this.a.a(string, true);
    }

    public void b(boolean bl2) {
        this.a.e(bl2);
    }

    public boolean b() {
        return this.a.C();
    }

    public void c(String string) {
        this.a.b(string);
    }

    public void c(boolean bl2) {
        this.a.g(bl2);
    }

    public boolean c() {
        return this.a.U();
    }

    public void d() {
        this.a.V();
    }

    public void d(String string) {
        this.a.c(string);
    }

    public Context e() {
        return this.a.l();
    }

    public ag f() {
        return this.a.h();
    }

    public dk g() {
        return this.a.ad();
    }

    public ef h() {
        return this.a.af();
    }

    public ef i() {
        return this.a.ag();
    }

    public boolean j() {
        return this.a.ae();
    }

    public void k() {
        this.a.ah();
    }

    public boolean l() {
        return this.a.i();
    }

    public boolean m() {
        return this.a.j();
    }

    public int n() {
        return this.a.t();
    }

    public int o() {
        return this.a.s();
    }

    public int p() {
        return this.a.p().h();
    }

    public int q() {
        return this.a.p().g();
    }

    public double r() {
        return this.a.x();
    }

    public void s() {
        this.a.k();
    }

    public void t() {
        this.a.ai();
    }

    public void u() {
        this.a.aj();
    }

    public String v() {
        return this.a.g();
    }

    public boolean w() {
        return this.a.ak();
    }

    public boolean x() {
        return this.a.Z();
    }

    public View y() {
        return this.a.al();
    }

    public Activity z() {
        return this.a.m();
    }
}

