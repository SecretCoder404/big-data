/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.amazon.device.ads.cr
 *  com.amazon.device.ads.cy
 *  java.lang.Object
 *  java.lang.String
 */
package com.amazon.device.ads;

import com.amazon.device.ads.cr;
import com.amazon.device.ads.cs;
import com.amazon.device.ads.cy;

class cz {
    cz() {
    }

    public cy a(String string) {
        return new cy((cs)new cr()).a(string);
    }
}

