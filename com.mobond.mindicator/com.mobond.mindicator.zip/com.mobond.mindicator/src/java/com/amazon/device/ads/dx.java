/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 */
package com.amazon.device.ads;

import com.amazon.device.ads.aq;
import com.amazon.device.ads.bk;
import com.amazon.device.ads.cv;
import com.amazon.device.ads.cx;
import com.amazon.device.ads.cz;
import com.amazon.device.ads.dw;

class dx
extends dw {
    private static final String c = "dx";
    private static final cv.a d = cv.a.P;

    public dx(aq aq2) {
        this(aq2, cx.a(), bk.a());
    }

    dx(aq aq2, cx cx2, bk bk2) {
        super(new cz(), c, d, "/generate_did", aq2, cx2, bk2);
    }
}

