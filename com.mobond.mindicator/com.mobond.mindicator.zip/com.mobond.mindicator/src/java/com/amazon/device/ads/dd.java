/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.amazon.device.ads;

class dd {
    public static final long a(long l2) {
        return l2 / 1000000L;
    }

    public static final long b(long l2) {
        return l2 * 1000L;
    }
}

