/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.amazon.device.ads.j
 *  java.lang.Object
 */
package com.amazon.device.ads;

import com.amazon.device.ads.er;
import com.amazon.device.ads.j;

public class es {
    public er a(j j2) {
        return new er(j2);
    }
}

