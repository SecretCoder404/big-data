/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.amazon.device.ads;

import com.amazon.device.ads.e;
import com.amazon.device.ads.m;
import com.amazon.device.ads.x;

public interface q {
    public void a(e var1);

    public void a(e var1, m var2);

    public void a(e var1, x var2);

    public void b(e var1);

    public void c(e var1);
}

