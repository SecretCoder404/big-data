/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.ViewGroup
 *  java.lang.Object
 */
package com.amazon.device.ads;

import android.view.ViewGroup;
import com.amazon.device.ads.eo;

class ep {
    private ViewGroup a;

    ep() {
    }

    public eo a() {
        return new eo(this.a);
    }

    public ep a(ViewGroup viewGroup) {
        this.a = viewGroup;
        return this;
    }
}

