/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.amazon.device.ads;

final class ag
extends Enum<ag> {
    public static final /* enum */ ag a = new ag();
    public static final /* enum */ ag b = new ag();
    public static final /* enum */ ag c = new ag();
    public static final /* enum */ ag d = new ag();
    public static final /* enum */ ag e = new ag();
    public static final /* enum */ ag f = new ag();
    public static final /* enum */ ag g = new ag();
    public static final /* enum */ ag h = new ag();
    public static final /* enum */ ag i = new ag();
    public static final /* enum */ ag j = new ag();
    public static final /* enum */ ag k = new ag();
    private static final /* synthetic */ ag[] l;

    static {
        ag[] arrag = new ag[]{a, b, c, d, e, f, g, h, i, j, k};
        l = arrag;
    }

    public static ag valueOf(String string) {
        return (ag)Enum.valueOf(ag.class, (String)string);
    }

    public static ag[] values() {
        return (ag[])l.clone();
    }
}

