/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 */
package com.amazon.device.ads;

import com.amazon.device.ads.aa;
import com.amazon.device.ads.aq;
import com.amazon.device.ads.b;
import com.amazon.device.ads.bn;
import com.amazon.device.ads.cz;
import com.amazon.device.ads.d;

class ar
extends d {
    ar() {
        this(bn.a(), new cz());
    }

    ar(bn bn2, cz cz2) {
        super(bn2, "idfa", "debug.idfa", cz2);
    }

    @Override
    protected String a(b.m m2) {
        return m2.b().d().b();
    }
}

