/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Rect
 *  java.lang.Object
 */
package com.amazon.device.ads;

import android.graphics.Rect;
import com.amazon.device.ads.e;
import com.amazon.device.ads.q;

public interface bw
extends q {
    public void a(e var1, Rect var2);

    public void d(e var1);
}

