/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.amazon.device.ads.j
 *  java.lang.Object
 */
package com.amazon.device.ads;

import com.amazon.device.ads.ew;
import com.amazon.device.ads.j;

public class ex {
    public ew a(j j2) {
        return new ew(j2);
    }
}

