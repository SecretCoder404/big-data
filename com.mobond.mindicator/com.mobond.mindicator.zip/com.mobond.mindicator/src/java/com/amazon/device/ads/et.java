/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  org.json.JSONObject
 */
package com.amazon.device.ads;

import org.json.JSONObject;

class et {
    private JSONObject a;
    private boolean b;

    public et(boolean bl2, JSONObject jSONObject) {
        this.a = jSONObject;
        this.b = bl2;
    }

    public boolean a() {
        return this.b;
    }

    public JSONObject b() {
        return this.a;
    }
}

