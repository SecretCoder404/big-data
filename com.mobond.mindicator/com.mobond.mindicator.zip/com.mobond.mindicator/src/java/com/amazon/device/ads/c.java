/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.amazon.device.ads.c$a
 *  com.amazon.device.ads.c$b
 *  java.lang.Object
 *  org.json.JSONObject
 */
package com.amazon.device.ads;

import com.amazon.device.ads.b;
import com.amazon.device.ads.c;
import org.json.JSONObject;

/*
 * Exception performing whole class analysis.
 */
abstract class c {
    public static final b a;
    public static final a b;

    static {
        a = new /* Unavailable Anonymous Inner Class!! */;
        b = new /* Unavailable Anonymous Inner Class!! */;
    }

    c() {
    }

    public abstract void a(b.m var1, JSONObject var2);
}

