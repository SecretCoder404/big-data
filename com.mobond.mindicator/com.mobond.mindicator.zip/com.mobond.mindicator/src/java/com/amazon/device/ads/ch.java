/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  java.io.InputStream
 */
package com.amazon.device.ads;

import android.graphics.Bitmap;
import com.amazon.device.ads.ce;
import com.amazon.device.ads.dr;
import java.io.InputStream;

class ch
extends dr {
    final ce a;

    ch(dr dr2, ce ce2) {
        super(dr2.b());
        this.a = ce2;
    }

    public Bitmap a() {
        return this.a.a(this.b());
    }
}

