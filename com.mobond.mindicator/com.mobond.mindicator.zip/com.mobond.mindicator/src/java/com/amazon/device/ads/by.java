/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.amazon.device.ads.bz
 *  com.amazon.device.ads.ca
 *  java.io.File
 *  java.lang.Object
 *  java.lang.String
 */
package com.amazon.device.ads;

import com.amazon.device.ads.bz;
import com.amazon.device.ads.ca;
import java.io.File;

interface by {
    public bz a(File var1, String var2);

    public ca a(String var1);

    public ca b(File var1, String var2);
}

