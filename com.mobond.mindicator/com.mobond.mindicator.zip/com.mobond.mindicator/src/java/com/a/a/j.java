/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Throwable
 */
package com.a.a;

import com.a.a.u;

public class j
extends u {
    public j() {
    }

    public j(Throwable throwable) {
        super(throwable);
    }
}

