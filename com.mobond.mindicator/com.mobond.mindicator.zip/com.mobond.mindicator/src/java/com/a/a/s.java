/*
 * Decompiled with CFR 0.0.
 */
package com.a.a;

import com.a.a.k;
import com.a.a.u;

public class s
extends u {
    public s() {
    }

    public s(k k2) {
        super(k2);
    }
}

