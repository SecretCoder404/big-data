/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.a.a;

import com.a.a.u;

public interface r {
    public int a();

    public void a(u var1);

    public int b();
}

