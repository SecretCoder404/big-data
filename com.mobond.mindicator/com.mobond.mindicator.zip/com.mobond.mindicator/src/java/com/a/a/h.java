/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.a.a;

import com.a.a.k;
import com.a.a.n;

public interface h {
    public k a(n<?> var1);
}

