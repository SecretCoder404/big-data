/*
 * Decompiled with CFR 0.0.
 */
package com.a.a;

import com.a.a.k;
import com.a.a.s;

public class d
extends s {
    public d() {
    }

    public d(k k2) {
        super(k2);
    }
}

