/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Map
 *  org.apache.http.HttpResponse
 */
package com.a.a.a;

import com.a.a.n;
import java.util.Map;
import org.apache.http.HttpResponse;

@Deprecated
public interface i {
    public HttpResponse b(n<?> var1, Map<String, String> var2);
}

