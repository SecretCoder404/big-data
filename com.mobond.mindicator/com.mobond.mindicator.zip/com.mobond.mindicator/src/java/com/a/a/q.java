/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 */
package com.a.a;

import com.a.a.n;
import com.a.a.p;
import com.a.a.u;

public interface q {
    public void a(n<?> var1, p<?> var2);

    public void a(n<?> var1, p<?> var2, Runnable var3);

    public void a(n<?> var1, u var2);
}

