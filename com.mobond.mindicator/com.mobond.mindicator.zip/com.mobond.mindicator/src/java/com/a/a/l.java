/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Throwable
 */
package com.a.a;

import com.a.a.j;

public class l
extends j {
    public l() {
    }

    public l(Throwable throwable) {
        super(throwable);
    }
}

