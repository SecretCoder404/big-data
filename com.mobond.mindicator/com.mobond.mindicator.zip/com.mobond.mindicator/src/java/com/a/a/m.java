/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Throwable
 */
package com.a.a;

import com.a.a.k;
import com.a.a.u;

public class m
extends u {
    public m() {
    }

    public m(k k2) {
        super(k2);
    }

    public m(Throwable throwable) {
        super(throwable);
    }
}

