/*
 * Decompiled with CFR 0.0.
 */
package com.b.a.b;

import com.b.a.b.e;
import com.b.a.b.f;
import com.b.a.b.i;
import com.b.a.b.l;
import com.b.a.b.m;

public class o
extends f
implements m {
    public o(l[] arrl, i i2) {
        super(arrl, i2);
    }

    @Override
    public boolean a(e e2, double d2) {
        if (!this.b(e2)) {
            return false;
        }
        return super.a(e2, d2);
    }
}

