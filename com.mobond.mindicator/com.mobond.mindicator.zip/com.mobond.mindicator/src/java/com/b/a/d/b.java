/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.b.a.d;

import com.b.a.b.e;
import com.b.a.d.a;
import com.b.a.d.c;

public class b {
    private e a;

    public b(e e2) {
        this.a = e2;
    }

    public double a(com.b.a.b.a a2) {
        return a.a(this.a, a2);
    }

    public com.b.a.b.a a(double d2) {
        return c.a(this.a, d2).c(this.a);
    }

    public double b(com.b.a.b.a a2) {
        return a.a(this.a, a2);
    }
}

