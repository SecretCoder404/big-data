/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.b.a.b;

import com.b.a.b.a;
import com.b.a.b.b;

public interface c {
    public b a(a[] var1);
}

