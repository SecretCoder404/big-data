/*
 * Decompiled with CFR 0.0.
 */
package com.b.a.b;

import com.b.a.b.e;
import com.b.a.b.f;
import com.b.a.b.i;
import com.b.a.b.s;

public class q
extends f {
    public q(s[] arrs, i i2) {
        super(arrs, i2);
    }

    @Override
    public boolean a(e e2, double d2) {
        if (!this.b(e2)) {
            return false;
        }
        return super.a(e2, d2);
    }
}

