/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Cloneable
 *  java.lang.Object
 */
package com.b.a.b;

import com.b.a.b.a;
import com.b.a.b.d;

public interface b
extends Cloneable {
    public int a();

    public a a(int var1);

    public d a(d var1);

    public void a(int var1, a var2);

    public double b(int var1);

    public a[] b();

    public double c(int var1);

    public Object clone();
}

