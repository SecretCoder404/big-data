/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.String
 */
package com.b.a.c;

public class a
extends Exception {
    public a(String string) {
        super(string);
    }
}

