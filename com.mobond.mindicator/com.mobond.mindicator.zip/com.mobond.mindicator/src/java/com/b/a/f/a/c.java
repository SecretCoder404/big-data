/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.b.a.f.a;

import com.b.a.b.a;
import com.b.a.b.e;

public class c {
    private e a = null;
    private int b;
    private a c = null;

    public c(e e2, int n2, a a2) {
        this.a = e2;
        this.b = n2;
        this.c = a2;
    }

    public c(e e2, a a2) {
        this(e2, -1, a2);
    }

    public a a() {
        return this.c;
    }
}

