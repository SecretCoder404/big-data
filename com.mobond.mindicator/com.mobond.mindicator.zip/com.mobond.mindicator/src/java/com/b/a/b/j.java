/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.b.a.b;

import com.b.a.b.e;

public interface j {
    public void a(e var1);
}

