/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.b.a.a.a$a
 *  com.b.a.a.a$b
 *  com.b.a.a.a$c
 *  com.b.a.a.a$d
 *  java.lang.Object
 */
package com.b.a.a;

import com.b.a.a.a;

public interface a {
    public static final a a;
    public static final a b;
    public static final a c;
    public static final a d;
    public static final a e;

    static {
        a = new /* Unavailable Anonymous Inner Class!! */;
        b = new /* Unavailable Anonymous Inner Class!! */;
        c = new /* Unavailable Anonymous Inner Class!! */;
        d = new /* Unavailable Anonymous Inner Class!! */;
        e = a;
    }

    public boolean a(int var1);
}

