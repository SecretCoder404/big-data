/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.RuntimeException
 *  java.lang.String
 */
package com.b.a.g;

public class b
extends RuntimeException {
    public b() {
    }

    public b(String string) {
        super(string);
    }
}

