/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 */
package com.b.a.b.a;

import com.b.a.b.a.a;
import com.b.a.b.c;
import java.io.Serializable;

public final class b
implements c,
Serializable {
    private static final b a = new b();

    private b() {
    }

    public static b a() {
        return a;
    }

    @Override
    public com.b.a.b.b a(com.b.a.b.a[] arra) {
        return new a(arra);
    }
}

