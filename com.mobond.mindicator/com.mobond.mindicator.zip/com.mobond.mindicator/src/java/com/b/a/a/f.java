/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.String
 */
package com.b.a.a;

public class f
extends Exception {
    public f() {
        super("Projective point not representable on the Cartesian plane.");
    }
}

