/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.davemorrissey.labs.subscaleview;

public final class R {
    private R() {
    }

    public static final class attr {
        public static final int assetName = 2130968623;
        public static final int panEnabled = 2130968980;
        public static final int quickScaleEnabled = 2130968999;
        public static final int src = 2130969030;
        public static final int tileBackgroundColor = 2130969120;
        public static final int zoomEnabled = 2130969167;

        private attr() {
        }
    }

    public static final class styleable {
        public static final int[] SubsamplingScaleImageView = new int[]{2130968623, 2130968980, 2130968999, 2130969030, 2130969120, 2130969167};
        public static final int SubsamplingScaleImageView_assetName = 0;
        public static final int SubsamplingScaleImageView_panEnabled = 1;
        public static final int SubsamplingScaleImageView_quickScaleEnabled = 2;
        public static final int SubsamplingScaleImageView_src = 3;
        public static final int SubsamplingScaleImageView_tileBackgroundColor = 4;
        public static final int SubsamplingScaleImageView_zoomEnabled = 5;

        private styleable() {
        }
    }

}

