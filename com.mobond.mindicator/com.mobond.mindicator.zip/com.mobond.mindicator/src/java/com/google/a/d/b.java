/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Object
 *  java.lang.String
 */
package com.google.a.d;

public final class b
extends Enum<b> {
    public static final /* enum */ b a = new b();
    public static final /* enum */ b b = new b();
    public static final /* enum */ b c = new b();
    public static final /* enum */ b d = new b();
    public static final /* enum */ b e = new b();
    public static final /* enum */ b f = new b();
    public static final /* enum */ b g = new b();
    public static final /* enum */ b h = new b();
    public static final /* enum */ b i = new b();
    public static final /* enum */ b j = new b();
    private static final /* synthetic */ b[] k;

    static {
        b[] arrb = new b[]{a, b, c, d, e, f, g, h, i, j};
        k = arrb;
    }

    public static b valueOf(String string) {
        return (b)Enum.valueOf(b.class, (String)string);
    }

    public static b[] values() {
        return (b[])k.clone();
    }
}

