/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.IOException
 *  java.lang.String
 */
package com.google.a.d;

import java.io.IOException;

public final class d
extends IOException {
    public d(String string) {
        super(string);
    }
}

