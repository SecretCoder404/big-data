/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.reflect.Type
 */
package com.google.a;

import java.lang.reflect.Type;

public interface h<T> {
    public T a(Type var1);
}

