/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.reflect.AccessibleObject
 */
package com.google.a.b.b;

import com.google.a.b.b.b;
import java.lang.reflect.AccessibleObject;

final class a
extends b {
    a() {
    }

    @Override
    public void a(AccessibleObject accessibleObject) {
        accessibleObject.setAccessible(true);
    }
}

