/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.a.b.a.n$1
 *  com.google.a.b.a.n$10
 *  com.google.a.b.a.n$11
 *  com.google.a.b.a.n$12
 *  com.google.a.b.a.n$13
 *  com.google.a.b.a.n$14
 *  com.google.a.b.a.n$15
 *  com.google.a.b.a.n$16
 *  com.google.a.b.a.n$17
 *  com.google.a.b.a.n$18
 *  com.google.a.b.a.n$19
 *  com.google.a.b.a.n$2
 *  com.google.a.b.a.n$20
 *  com.google.a.b.a.n$21
 *  com.google.a.b.a.n$22
 *  com.google.a.b.a.n$23
 *  com.google.a.b.a.n$24
 *  com.google.a.b.a.n$25
 *  com.google.a.b.a.n$26
 *  com.google.a.b.a.n$27
 *  com.google.a.b.a.n$28
 *  com.google.a.b.a.n$3
 *  com.google.a.b.a.n$30
 *  com.google.a.b.a.n$31
 *  com.google.a.b.a.n$32
 *  com.google.a.b.a.n$33
 *  com.google.a.b.a.n$34
 *  com.google.a.b.a.n$35
 *  com.google.a.b.a.n$4
 *  com.google.a.b.a.n$5
 *  com.google.a.b.a.n$6
 *  com.google.a.b.a.n$7
 *  com.google.a.b.a.n$8
 *  com.google.a.b.a.n$9
 *  java.lang.Boolean
 *  java.lang.Byte
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.Integer
 *  java.lang.NoSuchFieldError
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Short
 *  java.lang.String
 *  java.lang.StringBuffer
 *  java.lang.StringBuilder
 *  java.math.BigDecimal
 *  java.math.BigInteger
 *  java.net.InetAddress
 *  java.net.URI
 *  java.net.URL
 *  java.util.BitSet
 *  java.util.Calendar
 *  java.util.Currency
 *  java.util.GregorianCalendar
 *  java.util.Locale
 *  java.util.UUID
 *  java.util.concurrent.atomic.AtomicBoolean
 *  java.util.concurrent.atomic.AtomicInteger
 *  java.util.concurrent.atomic.AtomicIntegerArray
 */
package com.google.a.b.a;

import com.google.a.b.a.n;
import com.google.a.d.b;
import com.google.a.l;
import com.google.a.v;
import com.google.a.w;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.URI;
import java.net.URL;
import java.util.BitSet;
import java.util.Calendar;
import java.util.Currency;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicIntegerArray;

public final class n {
    public static final v<String> A;
    public static final v<BigDecimal> B;
    public static final v<BigInteger> C;
    public static final w D;
    public static final v<StringBuilder> E;
    public static final w F;
    public static final v<StringBuffer> G;
    public static final w H;
    public static final v<URL> I;
    public static final w J;
    public static final v<URI> K;
    public static final w L;
    public static final v<InetAddress> M;
    public static final w N;
    public static final v<UUID> O;
    public static final w P;
    public static final v<Currency> Q;
    public static final w R;
    public static final w S;
    public static final v<Calendar> T;
    public static final w U;
    public static final v<Locale> V;
    public static final w W;
    public static final v<l> X;
    public static final w Y;
    public static final w Z;
    public static final v<Class> a;
    public static final w b;
    public static final v<BitSet> c;
    public static final w d;
    public static final v<Boolean> e;
    public static final v<Boolean> f;
    public static final w g;
    public static final v<Number> h;
    public static final w i;
    public static final v<Number> j;
    public static final w k;
    public static final v<Number> l;
    public static final w m;
    public static final v<AtomicInteger> n;
    public static final w o;
    public static final v<AtomicBoolean> p;
    public static final w q;
    public static final v<AtomicIntegerArray> r;
    public static final w s;
    public static final v<Number> t;
    public static final v<Number> u;
    public static final v<Number> v;
    public static final v<Number> w;
    public static final w x;
    public static final v<Character> y;
    public static final w z;

    static {
        a = new 1().a();
        b = n.a(Class.class, a);
        c = new 12().a();
        d = n.a(BitSet.class, c);
        e = new 23();
        f = new 30();
        g = n.a(Boolean.TYPE, Boolean.class, e);
        h = new 31();
        i = n.a(Byte.TYPE, Byte.class, h);
        j = new 32();
        k = n.a(Short.TYPE, Short.class, j);
        l = new 33();
        m = n.a(Integer.TYPE, Integer.class, l);
        n = new 34().a();
        o = n.a(AtomicInteger.class, n);
        p = new 35().a();
        q = n.a(AtomicBoolean.class, p);
        r = new 2().a();
        s = n.a(AtomicIntegerArray.class, r);
        t = new 3();
        u = new 4();
        v = new 5();
        w = new 6();
        x = n.a(Number.class, w);
        y = new 7();
        z = n.a(Character.TYPE, Character.class, y);
        A = new 8();
        B = new 9();
        C = new 10();
        D = n.a(String.class, A);
        E = new 11();
        F = n.a(StringBuilder.class, E);
        G = new 13();
        H = n.a(StringBuffer.class, G);
        I = new 14();
        J = n.a(URL.class, I);
        K = new 15();
        L = n.a(URI.class, K);
        M = new 16();
        N = n.b(InetAddress.class, M);
        O = new 17();
        P = n.a(UUID.class, O);
        Q = new 18().a();
        R = n.a(Currency.class, Q);
        S = new 19();
        T = new 20();
        U = n.b(Calendar.class, GregorianCalendar.class, T);
        V = new 21();
        W = n.a(Locale.class, V);
        X = new 22();
        Y = n.b(l.class, X);
        Z = new 24();
    }

    public static <TT> w a(Class<TT> class_, v<TT> v2) {
        return new 25(class_, v2);
    }

    public static <TT> w a(Class<TT> class_, Class<TT> class_2, v<? super TT> v2) {
        return new 26(class_, class_2, v2);
    }

    public static <T1> w b(Class<T1> class_, v<T1> v2) {
        return new 28(class_, v2);
    }

    public static <TT> w b(Class<TT> class_, Class<? extends TT> class_2, v<? super TT> v2) {
        return new 27(class_, class_2, v2);
    }

}

