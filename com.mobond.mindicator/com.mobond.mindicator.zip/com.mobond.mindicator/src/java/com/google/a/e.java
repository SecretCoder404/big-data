/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.reflect.Field
 */
package com.google.a;

import java.lang.reflect.Field;

public interface e {
    public String a(Field var1);
}

