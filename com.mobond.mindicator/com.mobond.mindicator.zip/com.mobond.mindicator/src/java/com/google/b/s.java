/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.google.b;

import com.google.b.e;
import com.google.b.f;
import com.google.b.i;

public interface s<MessageType> {
    public MessageType b(f var1, i var2);

    public MessageType c(e var1, i var2);
}

