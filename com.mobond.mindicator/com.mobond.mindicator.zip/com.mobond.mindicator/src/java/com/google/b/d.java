/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.google.b;

public abstract class d {
    public abstract void a(byte[] var1, int var2, int var3);
}

