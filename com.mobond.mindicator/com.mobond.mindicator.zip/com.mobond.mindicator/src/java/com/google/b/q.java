/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.b.p
 *  java.lang.Object
 */
package com.google.b;

import com.google.b.p;

public interface q {
    public boolean o();

    public p s();
}

