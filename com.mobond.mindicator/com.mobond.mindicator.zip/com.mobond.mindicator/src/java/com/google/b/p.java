/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Cloneable
 *  java.lang.Object
 */
package com.google.b;

import com.google.b.e;
import com.google.b.g;
import com.google.b.q;
import com.google.b.s;

public interface p
extends q {
    public void a(g var1);

    public int e();

    public e i();

    public s<? extends p> k();

    public a r();

    public static interface a
    extends q,
    Cloneable {
        public a c(p var1);

        public p g();
    }

}

