/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.Map$Entry
 */
package com.google.b;

import com.google.b.n;
import com.google.b.o;
import com.google.b.p;
import java.util.Iterator;
import java.util.Map;

public class n
extends o {
    private final p b;

    public p a() {
        return this.a(this.b);
    }

    @Override
    public boolean equals(Object object) {
        return this.a().equals(object);
    }

    @Override
    public int hashCode() {
        return this.a().hashCode();
    }

    public String toString() {
        return this.a().toString();
    }

}

