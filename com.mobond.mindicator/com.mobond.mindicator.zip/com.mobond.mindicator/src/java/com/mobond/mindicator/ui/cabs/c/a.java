/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.mobond.mindicator.ui.cabs.c;

public interface a {
    public void a(int var1);
}

