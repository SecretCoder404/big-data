/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.mobond.mindicator.ui.indianrail.a;

import com.mobond.mindicator.ui.indianrail.a.f;

public class c {
    public String a;
    public String b;
    public int c;
    public String d;
    public int e;
    public int f;
    public int g;
    public f h;
    public String i;
    public String j;
    public String k;
    public String l;
    public String m;
    public String n;
}

