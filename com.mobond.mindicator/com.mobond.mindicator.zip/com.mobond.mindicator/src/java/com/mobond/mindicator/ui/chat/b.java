/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.ViewGroup
 *  android.widget.ImageView
 *  android.widget.LinearLayout
 *  android.widget.RelativeLayout
 *  android.widget.RelativeLayout$LayoutParams
 *  android.widget.TextView
 *  java.lang.Object
 */
package com.mobond.mindicator.ui.chat;

import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class b {
    public TextView a;
    public TextView b;
    public TextView c;
    public RelativeLayout d;
    public ViewGroup e;
    public LinearLayout f;
    public TextView g;
    public TextView h;
    public ImageView i;
    public ImageView j;
    public RelativeLayout.LayoutParams k;
    public TextView l;
    public TextView m;
    public LinearLayout n;
}

