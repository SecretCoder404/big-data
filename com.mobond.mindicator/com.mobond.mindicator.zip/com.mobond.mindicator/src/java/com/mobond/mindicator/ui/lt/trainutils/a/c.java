/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.mobond.mindicator.ui.lt.trainutils.a;

public class c {
    public double a;
    public String b;
    public String c;
    public String d;
    public String e;
    public int f;
    public boolean g;
    public long h;
    public double i;
    public boolean j = true;
    public String k;
}

