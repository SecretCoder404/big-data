/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.mobond.mindicator.ui.lt.trainutils.a;

class b {
    String a;
    float b;

    public b(String string, float f2) {
        this.a = string;
        this.b = f2;
    }
}

