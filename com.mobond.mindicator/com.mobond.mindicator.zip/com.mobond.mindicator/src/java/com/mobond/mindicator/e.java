/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Bitmap
 *  java.lang.Object
 *  java.lang.String
 */
package com.mobond.mindicator;

import android.graphics.Bitmap;

public class e {
    Bitmap a;
    String b;

    public e(Bitmap bitmap, String string) {
        this.a = bitmap;
        this.b = string;
    }

    public Bitmap a() {
        return this.a;
    }

    public String b() {
        return this.b;
    }
}

