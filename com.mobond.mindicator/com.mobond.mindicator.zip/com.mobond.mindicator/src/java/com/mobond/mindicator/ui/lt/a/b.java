/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.mobond.mindicator.ui.lt.a;

public class b {
    public String a;
    public String b;
    public String c;
    public String d;
    public int e = 0;
    public int f = 0;
    public String g = null;
    public boolean h = false;
}

