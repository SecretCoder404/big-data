/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.mobond.mindicator.ui.indianrail.alarm;

public class c {
    public int a;
    public long b;
    public String c;
    public String d;
    public String e;
    public String f;
    public int g;

    public c(int n2, long l2, String string, String string2, String string3, String string4, int n3) {
        this.a = n2;
        this.b = l2;
        this.c = string;
        this.e = string3;
        this.f = string4;
        this.d = string2;
        this.g = n3;
    }
}

