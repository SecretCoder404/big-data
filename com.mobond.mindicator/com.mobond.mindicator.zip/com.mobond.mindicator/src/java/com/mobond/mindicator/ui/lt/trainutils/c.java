/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.mobond.mindicator.ui.lt.trainutils;

class c {
    String a;
    int b;

    public c(String string, int n2) {
        this.a = string;
        this.b = n2;
    }
}

