/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.mobond.mindicator.ui.indianrail.irplugin;

public interface SeatAvailabilityInterface {
    public void onError(String var1);

    public void onSuccess(String var1);

    public void removeThread();
}

