/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.os.Bundle
 */
package com.mobond.mindicator.ui;

import android.app.Activity;
import android.os.Bundle;

public class RegistrationFormUI
extends Activity {
    protected void onCreate(Bundle bundle) {
        this.setContentView(2131493120);
        super.onCreate(bundle);
    }
}

