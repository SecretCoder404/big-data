/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.ArrayList
 */
package com.mobond.mindicator.ui.alert;

import com.mobond.mindicator.ui.alert.c;
import java.util.ArrayList;

class b {
    ArrayList<c> a;

    public b(ArrayList<c> arrayList) {
        this.a = arrayList;
    }
}

