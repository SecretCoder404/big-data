/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.mobond.mindicator.ui.indianrail.pnrstatus;

class f {
    public String a;
    public String b;
    public String c;
    public String d;
    public String e;
    public String f;
    int g;

    f() {
    }
}

