/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 */
package com.mobond.mindicator.ui.alert;

import java.io.Serializable;

public class c
implements Serializable {
    public String a;
    public String b;
    public String c;
    public String d;
}

