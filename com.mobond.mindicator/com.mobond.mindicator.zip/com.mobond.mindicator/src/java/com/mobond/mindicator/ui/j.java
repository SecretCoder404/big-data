/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ProgressDialog
 *  android.os.Handler
 *  java.lang.Object
 */
package com.mobond.mindicator.ui;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Handler;

public interface j {
    public void a(ProgressDialog var1);

    public ProgressDialog k();

    public Handler l();

    public Activity m();
}

