/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.mobond.mindicator.ui.indianrail.seatavailability.a;

public class a {
    public int a;
    public int b;
    public int c;
    public int d;
    public int e;
    public int f;

    public a(int n2, int n3, int n4, int n5, int n6, int n7) {
        this.a = n3;
        this.b = n4;
        this.c = n2;
        this.d = n5;
        this.e = n6;
        this.f = n7;
    }
}

