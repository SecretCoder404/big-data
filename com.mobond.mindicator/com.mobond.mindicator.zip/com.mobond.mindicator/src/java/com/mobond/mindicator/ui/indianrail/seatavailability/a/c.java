/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 */
package com.mobond.mindicator.ui.indianrail.seatavailability.a;

import java.util.HashMap;

public class c {
    public HashMap<String, String> a = new HashMap();
    public String[] b;
    public String[][] c = new String[][]{{"1A", null}, {"2A", null}, {"3A", null}, {"3E", null}, {"CC", null}, {"FC", null}, {"SL", null}, {"2S", null}, {"EC", null}, {"EA", null}, {"GN", null}};
    public String d = null;
}

