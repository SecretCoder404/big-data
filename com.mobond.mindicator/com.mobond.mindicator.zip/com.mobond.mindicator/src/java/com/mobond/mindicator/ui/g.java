/*
 * Decompiled with CFR 0.0.
 */
package com.mobond.mindicator.ui;

import com.mulo.a.d.c;

public class g
extends c {
}

