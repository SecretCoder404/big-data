/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package com.mobond.mindicator.ui;

public class k {
    public String a = "#000000";
    public String b = "#707070";
    public String c = "#d0d0d0";
    public String d = "#FFFFFF";
    public String e = "#C11921";
    public String f = "#FFFFFF";
    public int g = 1;
}

